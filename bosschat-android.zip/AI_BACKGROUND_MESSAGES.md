# BossChat — messages IA en arrière-plan

BossChat peut générer des messages spontanés de ses IA alors que l'interface est fermée.

- Le moteur Android `BossChatWorker` relit l'état enregistré par l'interface.
- Il utilise le fournisseur et les clés API déjà configurés dans BossChat.
- Il génère un message spontané d'une IA et le sauvegarde dans le chat.
- Une notification Android est affichée si les notifications BossChat sont activées.
- Appuyer sur la notification ouvre directement la conversation concernée.
- Le worker est reprogrammé après le redémarrage du téléphone.

## Limitation Android

Sans serveur push, Android ne garantit pas une exécution à chaque instant. WorkManager périodique a un intervalle minimal d'environ 15 minutes et peut être retardé par les mécanismes d'économie d'énergie. Cela permet le fonctionnement en arrière-plan sans serveur, mais ce n'est pas du temps réel.

Pour des messages IA réellement instantanés pendant que l'app est fermée, il faudrait déplacer la génération vers un service/backend distant capable de déclencher des notifications push.


## Fermeture complète

Le système fonctionne lorsque BossChat est retiré des applications récentes. Android peut toutefois suspendre ou bloquer tout travail en arrière-plan après un **Arrêt forcé** manuel de l’application dans les réglages : aucune application normale ne peut contourner cette restriction système. Pour une réception fiable après fermeture normale, WorkManager est utilisé et est reprogrammé après redémarrage du téléphone.

package com.tommy.bosschat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Affichage de notification Android partagé par les deux chemins possibles :
 * - BossChatWorker : app totalement fermée, cycle ~15 min en arrière-plan.
 * - AndroidBridge (MainActivity) : app ouverte ou en arrière-plan récent, message
 *   généré côté JS (réponse d'un contact, appel entrant...). L'API Web
 *   `Notification` ne fonctionnant pas dans une WebView Android, le JS appelle
 *   ce chemin natif à la place pour obtenir une vraie notification système.
 */
object BossChatNotifier {
    const val CHANNEL_ID = "bosschat_messages_v2"

    fun ensureChannel(context: Context) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Messages BossChat",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Messages des contacts de BossChat"
                    enableVibration(true)
                    setShowBadge(true)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    /** chatId peut être vide (ex: appel entrant) : la notification ouvre alors juste l'app. */
    fun showMessage(context: Context, title: String, text: String, chatId: String) {
        ensureChannel(context)
        val intent = Intent(context, MainActivity::class.java).apply {
            if (chatId.isNotBlank()) putExtra("openChatId", chatId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val requestCode = if (chatId.isNotBlank()) chatId.hashCode() else title.hashCode()
        val pending = PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setShowWhen(true)
            .setGroup(CHANNEL_ID)
            .setContentIntent(pending)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(requestCode, notif)
        } catch (e: SecurityException) {
            // Permission de notification refusée par l'utilisateur : on ignore.
        }
    }
}

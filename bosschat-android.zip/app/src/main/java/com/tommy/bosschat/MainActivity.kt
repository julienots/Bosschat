package com.tommy.bosschat

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotifPermissionIfNeeded()
        scheduleBackgroundWorker()

        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")

        val openChatIdAtLaunch = intent.getStringExtra("openChatId")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val arg = if (openChatIdAtLaunch != null) "'" + openChatIdAtLaunch.replace("'", "") + "'" else "null"
                webView.evaluateJavascript("if(window.mergeNativeState) window.mergeNativeState($arg);", null)
            }
        }
        webView.loadUrl("file:///android_asset/bosschat.html")
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.evaluateJavascript("if(window.mergeNativeState) window.mergeNativeState(null);", null)
        }
    }

    private fun requestNotifPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
            }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            "bosschat_messages_v2",
            "Messages BossChat",
            NotificationManager.IMPORTANCE_HIGH
        )
        channel.description = "Nouveaux messages des contacts IA de BossChat"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    /** Vérifie les nouveaux messages générés en arrière-plan toutes les ~15 min (minimum imposé par Android). */
    private fun scheduleBackgroundWorker() {
        val request = PeriodicWorkRequestBuilder<BossChatWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "bosschat_autonomous_messages",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    /** Pont JS <-> natif : la page web pousse/relit l'état complet ici. */
    class AndroidBridge(private val ctx: Context) {
        @JavascriptInterface
        fun saveState(json: String) {
            StateStore.write(ctx, json)
        }

        @JavascriptInterface
        fun getState(): String {
            return StateStore.read(ctx) ?: ""
        }
    }
}

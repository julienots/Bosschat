package com.tommy.bosschat

import android.content.Context
import java.io.File

/**
 * Fichier JSON partagé entre la WebView (via AndroidBridge) et le worker
 * en arrière-plan (BossChatWorker). C'est le seul point de vérité côté
 * natif : il reflète (contacts, chats, settings, memory, drafts).
 */
object StateStore {
    private const val FILE_NAME = "bosschat_state.json"

    @Synchronized
    fun write(ctx: Context, json: String) {
        try {
            File(ctx.filesDir, FILE_NAME).writeText(json)
        } catch (e: Exception) {
            // pas grave : on retentera à la prochaine sauvegarde
        }
    }

    @Synchronized
    fun read(ctx: Context): String? {
        return try {
            val f = File(ctx.filesDir, FILE_NAME)
            if (f.exists()) f.readText() else null
        } catch (e: Exception) {
            null
        }
    }
}

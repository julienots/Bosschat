package com.tommy.bosschat

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/**
 * Tourne périodiquement (toutes les ~15 min, minimum Android) même app fermée.
 * Relit l'état partagé (bosschat_state.json), décide si un contact IA écrit
 * spontanément, appelle directement l'API du fournisseur choisi, ajoute le
 * message au chat, réécrit l'état et déclenche une vraie notification.
 *
 * Limite honnête : ce n'est pas du "push" temps réel — Android n'autorise pas
 * un cycle plus rapide que 15 min pour du travail périodique en arrière-plan
 * sans serveur dédié, et le mode Doze peut encore le repousser.
 */
class BossChatWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    private val client = OkHttpClient.Builder()
        .callTimeout(25, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            runOnce()
        } catch (e: Exception) {
            // on ne fait jamais échouer le worker : on retentera au cycle suivant
        }
        Result.success()
    }

    private fun runOnce() {
        val raw = StateStore.read(applicationContext) ?: return
        val state = JSONObject(raw)
        val settings = state.optJSONObject("settings") ?: return
        if (!settings.optBoolean("autoMessages", true)) return
        val apiKeys = settings.optJSONArray("apiKeys") ?: return
        if (apiKeys.length() == 0) return
        val provider = settings.optString("provider", "")
        val model = settings.optString("model", "")
        if (provider.isEmpty() || model.isEmpty()) return
        if (Random.nextDouble() > 0.5) return // pour rester crédible, pas un message à chaque cycle

        val contacts = state.optJSONArray("contacts") ?: return
        val chats = state.optJSONArray("chats") ?: return
        if (chats.length() == 0) return

        val eligible = mutableListOf<Pair<JSONObject, JSONObject>>()
        for (i in 0 until chats.length()) {
            val chat = chats.getJSONObject(i)
            if (chat.optString("type") != "dm") continue
            val contact = findContact(contacts, chat.optString("contactId")) ?: continue
            if (contact.optLong("awayUntil", 0) > System.currentTimeMillis()) continue
            eligible.add(contact to chat)
        }
        if (eligible.isEmpty()) return
        val (contact, chat) = eligible[Random.nextInt(eligible.size)]

        val sys = buildString {
            append("Tu es un personnage dans \"BossChat\". L'utilisateur (${settings.optString("userName", "le patron")}) ")
            append("est le patron, tu incarnes ${contact.optString("name")}.\n")
            append("C'est TOI qui écris spontanément, sans être sollicité·e, comme une vraie personne qui pense ")
            append("à un sujet professionnel. 1 à 3 phrases courtes, en français, ton WhatsApp naturel, pas de markdown.\n")
            append("Réponds UNIQUEMENT avec un JSON valide de la forme : {\"message\":\"...\"}\n")
            append("Profil du patron : ${settings.optString("bossProfile", "")}\n")
            append("Ton personnage : ${contact.optString("system_prompt", "")}")
        }

        val key = apiKeys.getJSONObject(Random.nextInt(apiKeys.length())).optString("key")
        if (key.isBlank()) return

        val messageText = callProvider(provider, model, key, sys) ?: return
        if (messageText.isBlank()) return

        val newMsg = JSONObject()
            .put("id", "n" + System.currentTimeMillis())
            .put("sender", contact.optString("id"))
            .put("content", messageText)
            .put("time", currentTimeLabel())
            .put("ts", System.currentTimeMillis())
            .put("status", "sent")
        val msgs = chat.optJSONArray("messages") ?: JSONArray().also { chat.put("messages", it) }
        msgs.put(newMsg)
        chat.put("unread", chat.optInt("unread", 0) + 1)

        StateStore.write(applicationContext, state.toString())
        notify(contact.optString("name"), messageText, chat.optString("id"))
    }

    private fun findContact(contacts: JSONArray, id: String): JSONObject? {
        for (i in 0 until contacts.length()) {
            val c = contacts.getJSONObject(i)
            if (c.optString("id") == id) return c
        }
        return null
    }

    private fun currentTimeLabel(): String {
        val cal = java.util.Calendar.getInstance()
        return String.format("%02d:%02d", cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE))
    }

    private fun callProvider(provider: String, model: String, key: String, sys: String): String? = try {
        when (provider) {
            "mistral" -> callOpenAiStyle("https://api.mistral.ai/v1/chat/completions", model, key, sys)
            "groq" -> callOpenAiStyle("https://api.groq.com/openai/v1/chat/completions", model, key, sys)
            "gemini" -> callGemini(model, key, sys)
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    private fun callOpenAiStyle(url: String, model: String, key: String, sys: String): String? {
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.8)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", sys))
                    .put(JSONObject().put("role", "user").put("content", "(Écris ton message spontané au format JSON demandé.)"))
            )
        val req = Request.Builder().url(url)
            .addHeader("Authorization", "Bearer $key")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val json = JSONObject(resp.body?.string() ?: return null)
            val content = json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            return parseMessage(content)
        }
    }

    private fun callGemini(model: String, key: String, sys: String): String? {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user").put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", "(Écris ton message spontané au format JSON demandé.)"))
                    )
                )
            )
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val req = Request.Builder().url(url)
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val json = JSONObject(resp.body?.string() ?: return null)
            val content = json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getString("text")
            return parseMessage(content)
        }
    }

    private fun parseMessage(raw: String): String? = try {
        var c = raw.trim()
        c = c.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val m = JSONObject(c).optString("message", "")
        m.ifBlank { null }
    } catch (e: Exception) {
        raw.take(200)
    }

    private fun notify(contactName: String, text: String, chatId: String) {
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            putExtra("openChatId", chatId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            applicationContext, chatId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(applicationContext, "bosschat_messages")
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(contactName)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        try {
            NotificationManagerCompat.from(applicationContext).notify(chatId.hashCode(), notif)
        } catch (e: SecurityException) {
            // permission de notification refusée par l'utilisateur : on ignore
        }
    }
}

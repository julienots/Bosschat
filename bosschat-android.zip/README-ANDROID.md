# BossChat — Projet Android (APK via GitHub Actions)

## Ce que fait cette version, en plus de la PWA
- La WebView charge `bosschat.html` (identique à la version web) dans une app installée normalement.
- Un pont `AndroidBridge` synchronise l'état de l'app (contacts, discussions, réglages, clés API) vers un fichier natif à chaque sauvegarde.
- Un `Worker` Android tourne tout seul, **même app fermée**, environ toutes les 15 minutes (minimum imposé par Android pour du travail périodique sans serveur dédié — impossible de descendre plus bas sans passer par un vrai serveur de push). Il choisit un contact disponible, appelle directement l'API du fournisseur configuré (Mistral/Groq/Gemini), ajoute le message généré à la conversation, et déclenche une vraie notification Android.
- À la réouverture de l'app (ou son retour au premier plan), les messages générés en arrière-plan sont fusionnés dans l'affichage.

⚠️ Limite honnête : ~15 min est le meilleur rythme atteignable sans serveur (le mode Doze d'Android peut même l'espacer davantage). Ce n'est pas un vrai push instantané façon WhatsApp.

## Mettre le projet sur GitHub
1. Crée un dépôt GitHub vide (public ou privé).
2. Décompresse ce zip et pousse tout son contenu à la racine du dépôt (`git init`, `git add .`, `git commit -m "BossChat Android"`, `git remote add origin ...`, `git push`).
3. Va dans l'onglet **Actions** du dépôt : le workflow "Build BossChat APK" se lance automatiquement au push sur `main` (ou lance-le à la main via "Run workflow").
4. Une fois le job terminé (icône verte), ouvre le run → section **Artifacts** en bas de page → télécharge `bosschat-debug-apk`.
5. Décompresse ce petit zip : il contient `app-debug.apk`. Transfère-le sur ton téléphone et installe-le (autorise "sources inconnues" si demandé).

## Notes
- APK non signé "release", c'est un APK **debug** — parfait pour un usage perso, pas pour le Play Store.
- Les clés API restent uniquement sur le téléphone (fichier interne à l'app), jamais commitées dans le dépôt.
- Package : `com.tommy.bosschat`.
